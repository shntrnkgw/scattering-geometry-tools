# scattering-geometry-tools
Tools to process scattering data. 

## Installation

    $ pip install scattering-geometry-tools